#!/bin/bash

for i in {70,80,90,100,150,200,250,300,350,400,450,500};do
bash small_example.sh $i $1 $2
done

for 
python3 master_results.py
