#!/bin/bash
#script for setting the path to the submission files of the Dream Challenge HPN 8, to merge alle mean_value of each submission
FILES=./Backup/Prediction_vs_DreamGroups/*

#scoring of all groups against the aggregated network
for folder3 in $FILES;do
	for file3 in $folder3/*-Network.csv;do
	python3 dream_groups_scoring2.py $file3

	done
done

#scoring of the prediction against the submissions of the groups.
for folder4 in $FILES;do
	for file4 in $folder4/*-Network.csv;do
	python3 dream_groups_scoring.py $file4

	done
done


#this part merges all mean_values, where the prediction is scored against the submissions of the groups stored in:
# PredictionKM3_BESTFIT_vs_[rank]_[groupname]-Network.csv
for folder in $FILES;do
	for file in $folder/*-Network.csv;do
	python3 MeanScores_of_Prediction_vs_Submission.py $file

	done
done
#resulting csv.file is stored in 'MeanScores_of_Prediction_vs_Submission.csv'


#this part merges all mean_values, where the submissions of the groups are scored against the aggregated network stored in:
# [rank]_[groupname]-Network_vs_Aggregated.csv

for folder2 in $FILES;do
	for file2 in $folder2/*-Network_vs_Aggregated.csv;do
	python3 MeanScores_of_Submission_vs_Aggregated.py $file2

	done
done
