import sys,os
import csv
import argparse
import os.path
import re

if __name__ == "__main__":
	if len(sys.argv) != 2:
		print("Wrong input.")
		sys.exit()
	csv_input = sys.argv[1]
	#csv_input1 = os.path.join(csv_input,'*-Network.csv')
	#print(csv_input)


	with open('MeanScores_of_Prediction_vs_Submission.csv', mode='a') as csv_file:
		csv_writer = csv.writer(csv_file, delimiter =',')
		input_data = csv.reader(open(csv_input, "r"), delimiter=',')
		input_data_list = list(input_data)
		mean_bacc= input_data_list[36]
		mean_mcc = input_data_list[37]
		mean_acc = input_data_list[38]
		mean_pre= input_data_list[39]
		mean_rec= input_data_list[40]

		mean_mcc1=mean_mcc[1]
		mean_mcc_title=mean_mcc[0]
	
		mean_bacc1=mean_bacc[1]
		mean_bacc_title=mean_bacc[0]

		mean_acc1=mean_acc[1]
		mean_acc_title=mean_acc[0]

		mean_pre1=mean_pre[1]
		mean_pre_title=mean_pre[0]

		mean_rec1=mean_rec[1]
		mean_rec_title=mean_rec[0]
		

		#get groupnames and their rank
		grouplist=csv_input.split('/')
		grouplist1=grouplist[3]

		rank = grouplist1.split('_')
		rank1= rank[0]
		

		csv_writer.writerow([str(rank1),str(grouplist1),str(mean_mcc_title),str(mean_mcc1), str(mean_bacc_title),str(mean_bacc1), str(mean_acc_title), str(mean_acc1),str(mean_pre_title),str(mean_pre1),str(mean_rec_title),str(mean_rec1)])
		#csv_writer.writerow([str(grouplist1),str(mean_bacc_title),str(mean_bacc1)])
	csv_file.close()