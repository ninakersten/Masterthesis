#!/bin/bash


cd ./PyBoolNet/

#use R-3.4.3

#chmod 700 CSV2TXT_insilico.r

R CMD BATCH CSV2TXT_insilico.r
