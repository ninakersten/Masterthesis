import sys
from PyBoolNet import FileExchange
from PyBoolNet import InteractionGraphs as IGs


print("Enter the directory to the input file:")
x = input() # enters e.g.: directory to "output2.bnet"
print("Enter the name of the output file:")
y = input()

primes = FileExchange.bnet2primes(x)
igraph = IGs.primes2igraph(primes)
#print(igraph.edges())

sif_string = ""
for (source,dest) in igraph.edges():
	signs = list(igraph.adj[source][dest]["sign"])
	sif_string+= source+" "+str(signs)[1:][:-1]+" "+dest+"\n"
	print((source,dest))
	print(igraph.adj[source][dest]["sign"])

filename = y
file = open(filename, "a")
file.write(sif_string)
file.close()
print(sif_string)
#print(igraph.graph["edge"])
