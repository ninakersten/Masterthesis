#1. Versuch
#askdir1 <- readline(prompt = "Please enter the directory to the \"./TS2B/BooleanModeling2post/\" -folder  :")
#askdir2 <- readline(prompt = "Please enter the directory to the \"./TS2B/BooleanModeling2post/\" -folder  :")
#"/home/nina/Schreibtisch/Masterarbeit/Algorithmen/TS2B/"

#2.Versuch
#ifelse(interactive()==FALSE,
#       askdir<- ask, 
#       askdir <- readline(prompt="Please enter the directory to the ./CSV -folder:")
#)
askdir <-function(){
  toString(readline(prompt = "Please enter the directory to the ./CSV -folder:"))
}
input_askdir <- askdir()
#print(input_askdir)

#askdir2 <-function(){
#  toString(readline("Please enter the directory to the ./CSV -folder:"))
#}
#input_askdir2 <- askdir2()
#print(input_askdir2)

#myfunction <- function(askdir, askdir2){
#
#  askdir <- readline(prompt = "Please enter the directory to the ./CSV -folder:")
#  askdir2<- readline(prompt = "Please enter the directory to the ./CSV -folder:")
#  
#  if(askdir = FALSE | askdir2 = FALSE){
#    print("Something is missing!Please check your input")
#  }else{
#/home/nina/Schreibtisch/Masterarbeit/Algorithmen/TS2B/BooleanModeling2post/Pipeline/CSV/

#python.load("/home/nina/Schreibtisch/Masterarbeit/Algorithmen/TS2B/BooleanModeling2post/Pipeline/rPythonscript.py")
#system('python /home/nina/Schreibtisch/Masterarbeit/Algorithmen/TS2B/BooleanModeling2post/Pipeline/rPythonscript.py', wait = FALSE)
